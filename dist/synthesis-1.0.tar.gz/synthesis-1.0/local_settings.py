#!/usr/bin/env python
# Override Settings for settings.py

MODE = 'TEST'                               # This is the switch that runs the program in Test Mode.

# DB settings:
if MODE == 'PROD':
	DB_DATABASE = "coastaldb"
	DB_USER = "scottben"
	DB_PASSWD = "nx9353"
else:
	DB_DATABASE = "coastaldb_test"
	DB_USER = "scottben"
	DB_PASSWD = "nx9353"

BASE_PATH = "/home/scottben/Documents/Development/AlexandriaConsulting/repos/trunk/synthesis"

DEBUG = False									# Debug the application layer
DEBUG_ALCHEMY = False							# Debug the ORM Layer
DEBUG_DB = False								# Debug the DB layer of the application

# email configuration
SMTPSERVER = 'smtp.1and1.com'
SMTPPORT = 587
SMTPSENDER = 'scott@benninghoff.us'
SMTPSENDERPWD = 'nx9353laumeyer#'

PATH_TO_GPG = '/usr/bin/gpg'
PGPHOMEDIR = '/home/scottben/.gnugpg'
PASSPHRASE = 'nx9353laumeyer#'