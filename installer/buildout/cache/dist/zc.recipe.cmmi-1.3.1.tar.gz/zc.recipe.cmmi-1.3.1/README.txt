************************************************************
Recipe installing a download via configure/make/make install
************************************************************

The configure-make-make-install recipe automates installation of
configure-based source distribution into buildouts.

.. contents::


SVN version:

  <svn://svn.zope.org/repos/main/zc.recipe.cmmi/trunk#egg=zc.recipe.cmmi-dev>


.. note::

    This recipe is not expected to work in a Microsoft Windows environment.
