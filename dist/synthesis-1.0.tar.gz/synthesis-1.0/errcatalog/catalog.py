#!/usr/bin/env python

errorCatalog = {
    
    1000: [1000, 'Undefined Error'],
    1001: [1001, 'You must supply an output type to run nodebuilder'],
    1002: [1002, 'XML Documents must have unique keys in order to be imported into database']
        
    }
