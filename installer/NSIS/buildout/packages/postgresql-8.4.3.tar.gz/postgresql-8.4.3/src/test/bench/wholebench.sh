#!/bin/sh

sh create.sh
echo Running the benchmark....
sh runwisc.sh
