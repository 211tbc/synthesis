*******************************************************************
Recipe for building and installing a static version of the lxml egg
*******************************************************************

This recipe automates the installation of the ``lxml`` python package
and, additionally, builds it **statically** against dependent libraries
like ``libxml2``, ``libxlst``.

.. contents::

