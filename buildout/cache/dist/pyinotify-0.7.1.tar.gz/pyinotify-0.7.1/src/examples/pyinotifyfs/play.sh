#!/bin/sh
TMPFILE=/etc/toto
MP=/mnt/pyinotifyfs

ls -la "$MP"

mkdir "${MP}/tag1"
mkdir "${MP}/tag2"
mkdir "${MP}/tag3"
mkdir -p "${MP}/tag4/tag5/tag6/tag7"

echo "ls -la $MP"
ls -la "${MP}"
echo ""

rm -rf "${MP}/tag4/tag5/"

echo "ls -la $MP"
ls -la "${MP}"
echo ""

ln -s "$TMPFILE" "${MP}/tag1/tag2/sl"
ln -s "$TMPFILE" "${MP}/tag2/sl2"


ls -la "${MP}/tag1/"
ls -la "${MP}/tag1/sl"
ls -la "${MP}/tag1/tag2/"
ls -la "${MP}/tag1/tag2/tag3"
ls -la "${MP}/tag1/tag2/tag8"

getfattr -h -d "${MP}/tag1/sl"
getfattr -h -n system.vtagfs.tags "${MP}/tag1/sl"

touch "${MP}/tag2/tag1/foo"
echo "blabla" > "${MP}/tag2/foo"
echo "tlatla" >> "${MP}/tag1/foo"
cat "${MP}/tag2/tag1/foo"
rm -f "${MP}/tag1/foo"
touch "${MP}/tag2/tag3/foo"
ls -la "${MP}/tag3/tag2"
